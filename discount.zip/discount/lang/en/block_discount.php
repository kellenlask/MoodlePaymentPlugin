<?php

$string['pluginname'] = 'Discount Code Manager';
$string['discount'] = 'Discount Code Manager';
$string['pluginname'] = 'Discount Code Manager';
$string['form_link'] = 'Set Discount Code';
$string['discountsettings'] = 'Discounts';

?>
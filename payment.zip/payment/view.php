<?php
/*
 * This page sets up the basic Moodle page necessary to smack forms onto. The forms contain the actual display
 * code.
 */

require_once("../../config.php");
require_once("$CFG->dirroot/mod/payment/locallib.php");
require_once("$CFG->dirroot/mod/payment/deprecatedlib.php");
require_once("$CFG->libdir/pdflib.php");

?>